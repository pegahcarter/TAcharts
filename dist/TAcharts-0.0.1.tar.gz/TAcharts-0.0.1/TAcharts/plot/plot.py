from .bollinger import *
from .ichimoku import *
from .renko import *


class Plot:

    def __init__(self, *args, **kwargs):
        pass

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# 2019.01.07
# Looking for patterns of declarations between plots
